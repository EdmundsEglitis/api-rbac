import os
from datetime import timedelta

# Flask configuration
SECRET_KEY = os.environ.get("SESSION_SECRET", "dev-secret-key-change-in-production")
JWT_SECRET_KEY = os.environ.get("JWT_SECRET_KEY", SECRET_KEY)
DEBUG = True

# JWT configuration
JWT_ACCESS_TOKEN_EXPIRES = timedelta(hours=1)
JWT_REFRESH_TOKEN_EXPIRES = timedelta(days=30)
JWT_COOKIE_SECURE = False  # Set to True in production with HTTPS
JWT_TOKEN_LOCATION = ["headers", "cookies"]
JWT_COOKIE_CSRF_PROTECT = True
JWT_CSRF_CHECK_FORM = True

# Rate limiter
RATELIMIT_DEFAULT = "100 per day, 10 per minute"
RATELIMIT_STORAGE_URL = "memory://"
RATELIMIT_HEADERS_ENABLED = True

# Database
SQLALCHEMY_DATABASE_URI = os.environ.get("DATABASE_URL")
SQLALCHEMY_TRACK_MODIFICATIONS = False
SQLALCHEMY_ENGINE_OPTIONS = {
    "pool_recycle": 300,
    "pool_pre_ping": True,
}
