import unittest
import json
import os
from datetime import datetime

from app import app, db
from models import User, Content, Comment, TokenBlocklist
from config import SECRET_KEY

class SecureApiTests(unittest.TestCase):
    def setUp(self):
        # Set up a test environment
        app.config['TESTING'] = True
        app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///:memory:'
        app.config['WTF_CSRF_ENABLED'] = False  # Disable CSRF for testing
        
        self.app = app.test_client()
        
        with app.app_context():
            db.create_all()
            
            # Create test users with different roles
            admin = User(username="test_admin", email="admin@test.com", role="admin")
            admin.set_password("Admin123!")
            
            editor = User(username="test_editor", email="editor@test.com", role="editor")
            editor.set_password("Editor123!")
            
            moderator = User(username="test_moderator", email="moderator@test.com", role="moderator")
            moderator.set_password("Moderator123!")
            
            viewer = User(username="test_viewer", email="viewer@test.com", role="viewer")
            viewer.set_password("Viewer123!")
            
            db.session.add_all([admin, editor, moderator, viewer])
            db.session.commit()
            
            # Create some test content
            content = Content(title="Test Content", body="This is test content", user_id=1)
            db.session.add(content)
            db.session.commit()
            
            # Create a test comment
            comment = Comment(body="Test comment", user_id=4, content_id=1)
            db.session.add(comment)
            db.session.commit()
    
    def tearDown(self):
        with app.app_context():
            db.session.remove()
            db.drop_all()
    
    def login(self, username, password):
        return self.app.post('/login', data=dict(
            username=username,
            password=password
        ), follow_redirects=True)
    
    def get_tokens(self, username, password):
        # Login and extract tokens from cookies
        response = self.login(username, password)
        
        # Extract access token from cookie
        cookies = response.headers.getlist('Set-Cookie')
        access_token = None
        
        for cookie in cookies:
            if 'access_token_cookie' in cookie:
                start = cookie.find('access_token_cookie=') + len('access_token_cookie=')
                end = cookie.find(';', start)
                access_token = cookie[start:end]
                break
                
        return access_token

    def test_user_registration(self):
        response = self.app.post('/register', data=dict(
            username="new_user",
            email="new@test.com",
            password="Password123!",
            password2="Password123!"
        ), follow_redirects=True)
        
        self.assertEqual(response.status_code, 200)
        self.assertIn(b'Congratulations, you are now a registered user!', response.data)
        
        with app.app_context():
            user = User.query.filter_by(username="new_user").first()
            self.assertIsNotNone(user)
            self.assertEqual(user.role, 'viewer')  # Default role
    
    def test_login_success(self):
        response = self.login("test_admin", "Admin123!")
        self.assertEqual(response.status_code, 200)
        self.assertIn(b'Welcome back, test_admin!', response.data)
        
    def test_login_failure(self):
        response = self.login("test_admin", "wrongpassword")
        self.assertEqual(response.status_code, 200)
        self.assertIn(b'Invalid username or password', response.data)
    
    def test_role_authorization_admin(self):
        # Admin should be able to access admin panel
        access_token = self.get_tokens("test_admin", "Admin123!")
        
        response = self.app.get('/admin', headers={
            'Authorization': f'Bearer {access_token}'
        }, follow_redirects=True)
        
        self.assertEqual(response.status_code, 200)
        self.assertIn(b'Admin Panel', response.data)
    
    def test_role_authorization_viewer(self):
        # Viewer should not be able to access admin panel
        access_token = self.get_tokens("test_viewer", "Viewer123!")
        
        response = self.app.get('/admin', headers={
            'Authorization': f'Bearer {access_token}'
        }, follow_redirects=True)
        
        self.assertEqual(response.status_code, 403)
        self.assertIn(b'Access denied: insufficient privileges', response.data)
    
    def test_api_content_creation(self):
        # Only admin and editor can create content
        access_token = self.get_tokens("test_editor", "Editor123!")
        
        response = self.app.post('/api/content', 
            headers={
                'Authorization': f'Bearer {access_token}',
                'Content-Type': 'application/json'
            },
            data=json.dumps({
                'title': 'New Content',
                'body': 'This is new content'
            })
        )
        
        self.assertEqual(response.status_code, 201)
        data = json.loads(response.data)
        self.assertEqual(data['message'], 'Content created successfully')
    
    def test_api_content_creation_unauthorized(self):
        # Viewer cannot create content
        access_token = self.get_tokens("test_viewer", "Viewer123!")
        
        response = self.app.post('/api/content', 
            headers={
                'Authorization': f'Bearer {access_token}',
                'Content-Type': 'application/json'
            },
            data=json.dumps({
                'title': 'New Content',
                'body': 'This is new content'
            })
        )
        
        self.assertEqual(response.status_code, 403)
        data = json.loads(response.data)
        self.assertEqual(data['msg'], 'Access denied: insufficient privileges')
    
    def test_moderator_can_delete_comments(self):
        # Moderator should be able to delete comments
        access_token = self.get_tokens("test_moderator", "Moderator123!")
        
        response = self.app.delete('/api/comments/1', 
            headers={
                'Authorization': f'Bearer {access_token}'
            }
        )
        
        self.assertEqual(response.status_code, 200)
        data = json.loads(response.data)
        self.assertEqual(data['message'], 'Comment deleted successfully')
    
    def test_viewer_cannot_delete_others_comments(self):
        # Create another viewer
        with app.app_context():
            viewer2 = User(username="test_viewer2", email="viewer2@test.com", role="viewer")
            viewer2.set_password("Viewer123!")
            db.session.add(viewer2)
            db.session.commit()
        
        # Viewer cannot delete comments from others
        access_token = self.get_tokens("test_viewer2", "Viewer123!")
        
        response = self.app.delete('/api/comments/1', 
            headers={
                'Authorization': f'Bearer {access_token}'
            }
        )
        
        self.assertEqual(response.status_code, 403)
        data = json.loads(response.data)
        self.assertEqual(data['error'], 'You can only delete your own comments')
    
    def test_token_revocation(self):
        # First login to get token
        access_token = self.get_tokens("test_admin", "Admin123!")
        
        # Test token works
        response = self.app.get('/api/profile', 
            headers={
                'Authorization': f'Bearer {access_token}'
            }
        )
        self.assertEqual(response.status_code, 200)
        
        # Revoke token
        with app.app_context():
            # Extract jti from token
            import jwt
            decoded = jwt.decode(access_token, SECRET_KEY, algorithms=["HS256"], options={"verify_signature": False})
            jti = decoded['jti']
            
            # Add to blocklist
            db.session.add(TokenBlocklist(jti=jti, created_at=datetime.now()))
            db.session.commit()
        
        # Now token should be invalid
        response = self.app.get('/api/profile', 
            headers={
                'Authorization': f'Bearer {access_token}'
            }
        )
        self.assertEqual(response.status_code, 401)
        
    def test_rate_limiting(self):
        # Test rate limiting on check-auth endpoint
        access_token = self.get_tokens("test_admin", "Admin123!")
        
        # Make 6 requests (limit is 5 per minute)
        for i in range(5):
            response = self.app.get('/api/check-auth', 
                headers={
                    'Authorization': f'Bearer {access_token}'
                }
            )
            self.assertEqual(response.status_code, 200)
        
        # The 6th request should be rate limited
        response = self.app.get('/api/check-auth', 
            headers={
                'Authorization': f'Bearer {access_token}'
            }
        )
        self.assertEqual(response.status_code, 429)  # Too many requests

if __name__ == '__main__':
    unittest.main()
