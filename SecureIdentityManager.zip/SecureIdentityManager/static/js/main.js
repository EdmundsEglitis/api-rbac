// Main JavaScript file for the Secure Flask API app

// Get the JWT token from cookies
function getToken() {
    return document.cookie.split('; ')
        .find(row => row.startsWith('access_token_cookie='))
        ?.split('=')[1];
}

// Helper function to make authenticated API requests
async function apiRequest(url, method = 'GET', data = null) {
    const token = getToken();
    const options = {
        method,
        headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${token}`
        },
        credentials: 'same-origin'
    };
    
    if (data && (method === 'POST' || method === 'PUT')) {
        options.body = JSON.stringify(data);
    }
    
    try {
        const response = await fetch(url, options);
        
        // Handle rate limiting
        if (response.status === 429) {
            showAlert('Too many requests. Please try again later.', 'danger');
            return null;
        }
        
        // Handle unauthorized
        if (response.status === 401) {
            showAlert('Your session has expired. Please log in again.', 'warning');
            window.location.href = '/login';
            return null;
        }
        
        // Handle forbidden
        if (response.status === 403) {
            showAlert('You do not have permission to access this resource.', 'danger');
            return null;
        }
        
        const data = await response.json();
        return { status: response.status, data };
    } catch (error) {
        console.error('API request error:', error);
        showAlert('An error occurred while communicating with the server.', 'danger');
        return null;
    }
}

// Helper function to display alerts
function showAlert(message, type = 'info') {
    const alertContainer = document.createElement('div');
    alertContainer.className = `alert alert-${type} alert-dismissible fade show`;
    alertContainer.innerHTML = `
        ${message}
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    `;
    
    const container = document.querySelector('.container');
    container.insertBefore(alertContainer, container.firstChild);
    
    // Auto-dismiss after 5 seconds
    setTimeout(() => {
        alertContainer.remove();
    }, 5000);
}

// Content management functions
async function loadContent() {
    const contentList = document.getElementById('contentList');
    if (!contentList) return;
    
    const result = await apiRequest('/api/content');
    if (!result) return;
    
    const { data } = result;
    
    contentList.innerHTML = '';
    if (data.content && data.content.length > 0) {
        data.content.forEach(item => {
            const row = document.createElement('tr');
            row.innerHTML = `
                <td>${item.id}</td>
                <td><a href="#" class="content-detail" data-id="${item.id}">${item.title}</a></td>
                <td>${item.author}</td>
                <td>${new Date(item.created_at).toLocaleDateString()}</td>
                <td>${new Date(item.updated_at).toLocaleDateString()}</td>
                <td>
                    <div class="btn-group btn-group-sm" role="group">
                        <button type="button" class="btn btn-outline-primary view-content" data-id="${item.id}">View</button>
                        ${userRole === 'admin' || userRole === 'editor' ? 
                        `<button type="button" class="btn btn-outline-secondary edit-content" data-id="${item.id}">Edit</button>` : ''}
                        ${userRole === 'admin' ? 
                        `<button type="button" class="btn btn-outline-danger delete-content" data-id="${item.id}">Delete</button>` : ''}
                    </div>
                </td>
            `;
            contentList.appendChild(row);
        });
        
        // Add event listeners
        document.querySelectorAll('.content-detail, .view-content').forEach(btn => {
            btn.addEventListener('click', (e) => {
                e.preventDefault();
                showContentDetail(btn.dataset.id);
            });
        });
        
        document.querySelectorAll('.edit-content').forEach(btn => {
            btn.addEventListener('click', (e) => {
                e.preventDefault();
                showEditContent(btn.dataset.id);
            });
        });
        
        document.querySelectorAll('.delete-content').forEach(btn => {
            btn.addEventListener('click', (e) => {
                e.preventDefault();
                deleteContent(btn.dataset.id);
            });
        });
    } else {
        contentList.innerHTML = `<tr><td colspan="6" class="text-center">No content available</td></tr>`;
    }
}

async function showContentDetail(contentId) {
    const result = await apiRequest(`/api/content/${contentId}`);
    if (!result) return;
    
    const { data } = result;
    
    // Populate modal with content details
    document.getElementById('contentTitle').textContent = data.title;
    document.getElementById('contentAuthor').textContent = data.author;
    document.getElementById('contentDate').textContent = new Date(data.created_at).toLocaleDateString();
    document.getElementById('contentBody').innerHTML = data.body;
    
    // Set up action buttons
    const editBtn = document.getElementById('editContentBtn');
    if (editBtn) {
        editBtn.dataset.id = contentId;
        editBtn.addEventListener('click', () => showEditContent(contentId));
    }
    
    const deleteBtn = document.getElementById('deleteContentBtn');
    if (deleteBtn) {
        deleteBtn.dataset.id = contentId;
        deleteBtn.addEventListener('click', () => deleteContent(contentId));
    }
    
    // Load comments
    const commentsList = document.getElementById('commentsList');
    commentsList.innerHTML = '';
    
    if (data.comments && data.comments.length > 0) {
        data.comments.forEach(comment => {
            const commentDiv = document.createElement('div');
            commentDiv.className = 'card mb-2';
            commentDiv.innerHTML = `
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-center">
                        <h6 class="card-subtitle mb-2 text-muted">${comment.author} - ${new Date(comment.created_at).toLocaleDateString()}</h6>
                        ${userRole === 'admin' || userRole === 'moderator' || comment.author === userName ? 
                        `<button class="btn btn-sm btn-outline-danger delete-comment" data-id="${comment.id}">Delete</button>` : ''}
                    </div>
                    <p class="card-text">${comment.body}</p>
                </div>
            `;
            commentsList.appendChild(commentDiv);
        });
        
        // Add delete comment event listeners
        document.querySelectorAll('.delete-comment').forEach(btn => {
            btn.addEventListener('click', () => deleteComment(btn.dataset.id));
        });
    } else {
        commentsList.innerHTML = '<p class="text-muted">No comments yet.</p>';
    }
    
    // Set up add comment form
    const addCommentForm = document.getElementById('addCommentForm');
    addCommentForm.onsubmit = (e) => {
        e.preventDefault();
        const commentBody = document.getElementById('commentBody').value;
        addComment(contentId, commentBody);
    };
    
    // Show modal
    const modal = new bootstrap.Modal(document.getElementById('contentDetailModal'));
    modal.show();
}

async function addComment(contentId, body) {
    if (!body.trim()) {
        showAlert('Comment cannot be empty', 'danger');
        return;
    }
    
    const result = await apiRequest(`/api/content/${contentId}/comments`, 'POST', { body });
    if (!result) return;
    
    showAlert('Comment added successfully', 'success');
    document.getElementById('commentBody').value = '';
    
    // Refresh content detail view
    showContentDetail(contentId);
}

async function deleteComment(commentId) {
    if (!confirm('Are you sure you want to delete this comment?')) return;
    
    const result = await apiRequest(`/api/comments/${commentId}`, 'DELETE');
    if (!result) return;
    
    showAlert('Comment deleted successfully', 'success');
    
    // Close and reopen detail modal to refresh
    const modal = bootstrap.Modal.getInstance(document.getElementById('contentDetailModal'));
    const contentId = document.getElementById('editContentBtn').dataset.id;
    modal.hide();
    setTimeout(() => showContentDetail(contentId), 500);
}

async function createContent() {
    const title = document.getElementById('contentTitleInput').value;
    const body = document.getElementById('contentBodyInput').value;
    
    if (!title.trim() || !body.trim()) {
        showAlert('Title and content are required', 'danger');
        return;
    }
    
    const result = await apiRequest('/api/content', 'POST', { title, body });
    if (!result) return;
    
    showAlert('Content created successfully', 'success');
    
    // Close modal and refresh content list
    const modal = bootstrap.Modal.getInstance(document.getElementById('createContentModal'));
    modal.hide();
    
    // Reset form
    document.getElementById('contentTitleInput').value = '';
    document.getElementById('contentBodyInput').value = '';
    
    // Reload content list
    loadContent();
}

async function showEditContent(contentId) {
    const result = await apiRequest(`/api/content/${contentId}`);
    if (!result) return;
    
    const { data } = result;
    
    // Populate edit form
    document.getElementById('editContentId').value = contentId;
    document.getElementById('editContentTitleInput').value = data.title;
    document.getElementById('editContentBodyInput').value = data.body;
    
    // Set up update button
    document.getElementById('updateContentBtn').onclick = updateContent;
    
    // Show modal
    const contentDetailModal = bootstrap.Modal.getInstance(document.getElementById('contentDetailModal'));
    if (contentDetailModal) contentDetailModal.hide();
    
    const modal = new bootstrap.Modal(document.getElementById('editContentModal'));
    modal.show();
}

async function updateContent() {
    const contentId = document.getElementById('editContentId').value;
    const title = document.getElementById('editContentTitleInput').value;
    const body = document.getElementById('editContentBodyInput').value;
    
    if (!title.trim() || !body.trim()) {
        showAlert('Title and content are required', 'danger');
        return;
    }
    
    const result = await apiRequest(`/api/content/${contentId}`, 'PUT', { title, body });
    if (!result) return;
    
    showAlert('Content updated successfully', 'success');
    
    // Close modal and refresh content list
    const modal = bootstrap.Modal.getInstance(document.getElementById('editContentModal'));
    modal.hide();
    
    // Reload content list
    loadContent();
}

async function deleteContent(contentId) {
    if (!confirm('Are you sure you want to delete this content? This will also delete all associated comments.')) return;
    
    const result = await apiRequest(`/api/content/${contentId}`, 'DELETE');
    if (!result) return;
    
    showAlert('Content deleted successfully', 'success');
    
    // Close detail modal if open
    const modal = bootstrap.Modal.getInstance(document.getElementById('contentDetailModal'));
    if (modal) modal.hide();
    
    // Reload content list
    loadContent();
}

// Comment moderation functions
async function loadComments() {
    const commentsList = document.getElementById('commentsList');
    if (!commentsList) return;
    
    // First load all content
    const result = await apiRequest('/api/content');
    if (!result) return;
    
    const { data } = result;
    
    // Collect all comments from all content
    let allComments = [];
    for (const content of data.content) {
        const contentDetail = await apiRequest(`/api/content/${content.id}`);
        if (contentDetail && contentDetail.data.comments) {
            contentDetail.data.comments.forEach(comment => {
                comment.contentTitle = content.title;
                comment.contentId = content.id;
                allComments.push(comment);
            });
        }
    }
    
    // Sort comments by date (newest first)
    allComments.sort((a, b) => new Date(b.created_at) - new Date(a.created_at));
    
    // Display comments
    commentsList.innerHTML = '';
    if (allComments.length > 0) {
        allComments.forEach(comment => {
            const row = document.createElement('tr');
            row.innerHTML = `
                <td>${comment.id}</td>
                <td><a href="#" class="content-link" data-id="${comment.contentId}">${comment.contentTitle}</a></td>
                <td>${comment.body}</td>
                <td>${comment.author}</td>
                <td>${new Date(comment.created_at).toLocaleDateString()}</td>
                <td>
                    ${userRole === 'admin' || userRole === 'moderator' ? 
                    `<button class="btn btn-sm btn-outline-danger delete-comment" data-id="${comment.id}">Delete</button>` : ''}
                </td>
            `;
            commentsList.appendChild(row);
        });
        
        // Add event listeners
        document.querySelectorAll('.content-link').forEach(link => {
            link.addEventListener('click', (e) => {
                e.preventDefault();
                window.location.href = `/content/${link.dataset.id}`;
            });
        });
        
        document.querySelectorAll('.delete-comment').forEach(btn => {
            btn.addEventListener('click', () => deleteComment(btn.dataset.id));
        });
    } else {
        commentsList.innerHTML = `<tr><td colspan="6" class="text-center">No comments available</td></tr>`;
    }
}

// Initialize page based on current path
document.addEventListener('DOMContentLoaded', () => {
    // Extract the current user role and username from the page if available
    window.userRole = document.querySelector('.dropdown-toggle')?.textContent?.match(/\((.*?)\)/)?.[1] || 'viewer';
    window.userName = document.querySelector('.dropdown-toggle')?.textContent?.split(' ')[0] || '';

    // Set up save button for content creation
    const saveContentBtn = document.getElementById('saveContentBtn');
    if (saveContentBtn) {
        saveContentBtn.addEventListener('click', createContent);
    }
    
    // Load data based on current page
    const path = window.location.pathname;
    
    if (path.includes('/content')) {
        loadContent();
    } else if (path.includes('/comments')) {
        loadComments();
    }
});
