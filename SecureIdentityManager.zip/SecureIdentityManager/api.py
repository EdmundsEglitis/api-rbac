import logging
from flask import Blueprint, jsonify, request, current_app
from flask_jwt_extended import jwt_required, get_jwt_identity, get_jwt
from flask_login import current_user, login_required
from flask_limiter import Limiter
from flask_limiter.util import get_remote_address

from models import db, User, Content, Comment
from security import role_required

api_bp = Blueprint('api', __name__)
logger = logging.getLogger(__name__)

limiter = Limiter(
    get_remote_address,
    default_limits=["100 per day", "10 per minute"],
    storage_uri="memory://",
)

# User management - Admin only endpoints
@api_bp.route('/users', methods=['GET'])
@jwt_required()
@role_required('admin')
def get_users():
    """Get all users - Admin only"""
    users = User.query.all()
    result = []
    for user in users:
        result.append({
            'id': user.id,
            'username': user.username,
            'email': user.email,
            'role': user.role
        })
    return jsonify({'users': result})

@api_bp.route('/users/<int:user_id>', methods=['GET'])
@jwt_required()
@role_required('admin')
def get_user(user_id):
    """Get a specific user - Admin only"""
    user = User.query.get_or_404(user_id)
    return jsonify({
        'id': user.id,
        'username': user.username,
        'email': user.email,
        'role': user.role
    })

@api_bp.route('/users/<int:user_id>', methods=['PUT'])
@jwt_required()
@role_required('admin')
def update_user(user_id):
    """Update a user - Admin only"""
    user = User.query.get_or_404(user_id)
    data = request.get_json()
    
    if 'username' in data:
        user.username = data['username']
    if 'email' in data:
        user.email = data['email']
    if 'role' in data:
        # Validate role
        valid_roles = ['admin', 'editor', 'moderator', 'viewer']
        if data['role'] not in valid_roles:
            return jsonify({'error': 'Invalid role specified'}), 400
        user.role = data['role']
    if 'password' in data:
        user.set_password(data['password'])
        
    db.session.commit()
    return jsonify({'message': 'User updated successfully'})

@api_bp.route('/users/<int:user_id>', methods=['DELETE'])
@jwt_required()
@role_required('admin')
def delete_user(user_id):
    """Delete a user - Admin only"""
    user = User.query.get_or_404(user_id)
    
    # Prevent deleting yourself
    current_user_id = get_jwt_identity()
    if user_id == current_user_id:
        return jsonify({'error': 'You cannot delete your own account'}), 400
    
    db.session.delete(user)
    db.session.commit()
    return jsonify({'message': 'User deleted successfully'})

# Content management endpoints
@api_bp.route('/content', methods=['GET'])
@jwt_required()
def get_all_content():
    """Get all content - Available to all authenticated users"""
    content = Content.query.all()
    result = []
    for item in content:
        result.append({
            'id': item.id,
            'title': item.title,
            'body': item.body,
            'author': item.author.username,
            'created_at': item.created_at.isoformat(),
            'updated_at': item.updated_at.isoformat()
        })
    return jsonify({'content': result})

@api_bp.route('/content/<int:content_id>', methods=['GET'])
@jwt_required()
def get_content(content_id):
    """Get specific content - Available to all authenticated users"""
    content = Content.query.get_or_404(content_id)
    
    comments = []
    for comment in content.comments:
        comments.append({
            'id': comment.id,
            'body': comment.body,
            'author': comment.author.username,
            'created_at': comment.created_at.isoformat()
        })
    
    return jsonify({
        'id': content.id,
        'title': content.title,
        'body': content.body,
        'author': content.author.username,
        'created_at': content.created_at.isoformat(),
        'updated_at': content.updated_at.isoformat(),
        'comments': comments
    })

@api_bp.route('/content', methods=['POST'])
@jwt_required()
@role_required('admin', 'editor')
def create_content():
    """Create new content - Admin and Editor only"""
    data = request.get_json()
    
    if not data or 'title' not in data or 'body' not in data:
        return jsonify({'error': 'Title and body are required'}), 400
    
    user_id = get_jwt_identity()
    
    content = Content(
        title=data['title'],
        body=data['body'],
        user_id=user_id
    )
    
    db.session.add(content)
    db.session.commit()
    
    return jsonify({
        'message': 'Content created successfully',
        'content_id': content.id
    }), 201

@api_bp.route('/content/<int:content_id>', methods=['PUT'])
@jwt_required()
@role_required('admin', 'editor')
def update_content(content_id):
    """Update content - Admin and Editor only"""
    content = Content.query.get_or_404(content_id)
    data = request.get_json()
    
    # Editor can only edit their own content, admin can edit any
    user_id = get_jwt_identity()
    claims = get_jwt()
    user_role = claims.get('role', '')
    
    if user_role != 'admin' and content.user_id != user_id:
        return jsonify({'error': 'You can only edit your own content'}), 403
    
    if 'title' in data:
        content.title = data['title']
    if 'body' in data:
        content.body = data['body']
        
    db.session.commit()
    return jsonify({'message': 'Content updated successfully'})

@api_bp.route('/content/<int:content_id>', methods=['DELETE'])
@jwt_required()
@role_required('admin')
def delete_content(content_id):
    """Delete content - Admin only"""
    content = Content.query.get_or_404(content_id)
    
    db.session.delete(content)
    db.session.commit()
    return jsonify({'message': 'Content deleted successfully'})

# Comment management endpoints
@api_bp.route('/content/<int:content_id>/comments', methods=['POST'])
@jwt_required()
def add_comment(content_id):
    """Add a comment - Available to all authenticated users"""
    content = Content.query.get_or_404(content_id)
    data = request.get_json()
    
    if not data or 'body' not in data:
        return jsonify({'error': 'Comment body is required'}), 400
    
    user_id = get_jwt_identity()
    
    comment = Comment(
        body=data['body'],
        user_id=user_id,
        content_id=content_id
    )
    
    db.session.add(comment)
    db.session.commit()
    
    return jsonify({
        'message': 'Comment added successfully',
        'comment_id': comment.id
    }), 201

@api_bp.route('/comments/<int:comment_id>', methods=['DELETE'])
@jwt_required()
def delete_comment(comment_id):
    """Delete a comment - Admin, Moderator, or comment author only"""
    comment = Comment.query.get_or_404(comment_id)
    
    user_id = get_jwt_identity()
    claims = get_jwt()
    user_role = claims.get('role', '')
    
    # Check if user is admin, moderator, or the comment author
    if user_role not in ['admin', 'moderator'] and comment.user_id != user_id:
        return jsonify({'error': 'You can only delete your own comments'}), 403
    
    db.session.delete(comment)
    db.session.commit()
    return jsonify({'message': 'Comment deleted successfully'})

# Profile endpoint
@api_bp.route('/profile', methods=['GET'])
@jwt_required()
def get_profile():
    """Get user profile - Available to authenticated user"""
    user_id = get_jwt_identity()
    user = User.query.get_or_404(user_id)
    
    return jsonify({
        'id': user.id,
        'username': user.username,
        'email': user.email,
        'role': user.role
    })

# Rate limited endpoint example
@api_bp.route('/check-auth', methods=['GET'])
@jwt_required()
@limiter.limit("5 per minute")
def check_auth():
    """Rate-limited endpoint to check authentication"""
    user_id = get_jwt_identity()
    claims = get_jwt()
    
    return jsonify({
        'authenticated': True,
        'user_id': user_id,
        'role': claims.get('role', '')
    })
