import logging
from datetime import datetime, timezone
from flask import Blueprint, request, jsonify, render_template, redirect, url_for, flash, session, make_response
from flask_jwt_extended import (
    create_access_token, create_refresh_token, get_jwt_identity,
    jwt_required, get_jwt, set_access_cookies, set_refresh_cookies,
    unset_jwt_cookies
)
from flask_wtf import FlaskForm
from wtforms import StringField, PasswordField, SubmitField, SelectField
from wtforms.validators import DataRequired, Email, EqualTo, Length, ValidationError
from flask_limiter import Limiter
from flask_limiter.util import get_remote_address
from flask_login import login_user, logout_user, login_required, current_user

from models import db, User, TokenBlocklist
from security import verify_password_strength, role_required

auth_bp = Blueprint('auth', __name__)
logger = logging.getLogger(__name__)

class LoginForm(FlaskForm):
    username = StringField('Username', validators=[DataRequired()])
    password = PasswordField('Password', validators=[DataRequired()])
    submit = SubmitField('Sign In')

class RegisterForm(FlaskForm):
    username = StringField('Username', validators=[DataRequired(), Length(min=3, max=64)])
    email = StringField('Email', validators=[DataRequired(), Email()])
    password = PasswordField('Password', validators=[DataRequired(), Length(min=8)])
    password2 = PasswordField('Repeat Password', validators=[DataRequired(), EqualTo('password')])
    submit = SubmitField('Register')
    
    def validate_username(self, username):
        user = User.query.filter_by(username=username.data).first()
        if user is not None:
            raise ValidationError('Please use a different username.')
            
    def validate_email(self, email):
        user = User.query.filter_by(email=email.data).first()
        if user is not None:
            raise ValidationError('Please use a different email address.')
        
class UserCreateForm(FlaskForm):
    username = StringField('Username', validators=[DataRequired(), Length(min=3, max=64)])
    email = StringField('Email', validators=[DataRequired(), Email()])
    password = PasswordField('Password', validators=[DataRequired(), Length(min=8)])
    role = SelectField('Role', choices=[
        ('admin', 'Admin'), 
        ('editor', 'Editor'), 
        ('moderator', 'Moderator'), 
        ('viewer', 'Viewer')
    ])
    submit = SubmitField('Create User')

@auth_bp.route('/register', methods=['GET', 'POST'])
def register():
    # In a production environment, you might want to restrict 
    # registration or require admin approval
    if current_user.is_authenticated:
        return redirect(url_for('auth.dashboard'))
    
    form = RegisterForm()
    if form.validate_on_submit():
        # Check password strength
        if not verify_password_strength(form.password.data):
            flash('Password is not strong enough. It should contain at least 8 characters, uppercase, lowercase, and numbers.', 'danger')
            return render_template('register.html', form=form, title='Register')
        
        user = User(
            username=form.username.data,
            email=form.email.data,
            role='viewer'  # Default role for new users
        )
        user.set_password(form.password.data)
        
        try:
            db.session.add(user)
            db.session.commit()
            flash('Congratulations, you are now a registered user!', 'success')
            return redirect(url_for('auth.login'))
        except Exception as e:
            db.session.rollback()
            logger.error(f"Registration error: {e}")
            flash('An error occurred during registration. Please try again.', 'danger')
    
    return render_template('register.html', form=form, title='Register')

@auth_bp.route('/login', methods=['GET', 'POST'])
def login():
    if current_user.is_authenticated:
        return redirect(url_for('auth.dashboard'))
    
    form = LoginForm()
    if form.validate_on_submit():
        user = User.query.filter_by(username=form.username.data).first()
        
        if user is None or not user.check_password(form.password.data):
            flash('Invalid username or password', 'danger')
            logger.warning(f"Failed login attempt for username: {form.username.data}")
            return render_template('login.html', form=form, title='Sign In')
        
        login_user(user)
        
        # Create JWT tokens
        access_token = create_access_token(identity=user.id, additional_claims={"role": user.role})
        refresh_token = create_refresh_token(identity=user.id)
        
        # Store tokens in cookies for API usage
        response = make_response(redirect(url_for('auth.dashboard')))
        set_access_cookies(response, access_token)
        set_refresh_cookies(response, refresh_token)
        
        flash(f'Welcome back, {user.username}!', 'success')
        logger.info(f"User {user.username} logged in successfully")
        return response
    
    return render_template('login.html', form=form, title='Sign In')

@auth_bp.route('/logout')
@login_required
def logout():
    # Flask-Login logout
    logout_user()
    
    # Create response and clear JWT cookies
    response = make_response(redirect(url_for('auth.login')))
    unset_jwt_cookies(response)
    
    flash('You have been logged out.', 'info')
    return response

@auth_bp.route('/dashboard')
@login_required
def dashboard():
    return render_template('dashboard.html', title='Dashboard')

@auth_bp.route('/admin')
@login_required
@role_required('admin')
def admin_panel():
    users = User.query.all()
    form = UserCreateForm()
    return render_template('admin.html', title='Admin Panel', users=users, form=form)

@auth_bp.route('/admin/create_user', methods=['POST'])
@login_required
@role_required('admin')
def create_user():
    form = UserCreateForm()
    if form.validate_on_submit():
        user = User(
            username=form.username.data,
            email=form.email.data,
            role=form.role.data
        )
        user.set_password(form.password.data)
        
        try:
            db.session.add(user)
            db.session.commit()
            flash(f'User {user.username} created successfully!', 'success')
        except Exception as e:
            db.session.rollback()
            logger.error(f"User creation error: {e}")
            flash('An error occurred while creating the user.', 'danger')
    else:
        for field, errors in form.errors.items():
            for error in errors:
                flash(f"{field}: {error}", 'danger')
    
    return redirect(url_for('auth.admin_panel'))

@auth_bp.route('/admin/delete_user/<int:user_id>', methods=['POST'])
@login_required
@role_required('admin')
def delete_user(user_id):
    user = User.query.get_or_404(user_id)
    
    if user.id == current_user.id:
        flash('You cannot delete yourself!', 'danger')
        return redirect(url_for('auth.admin_panel'))
        
    try:
        db.session.delete(user)
        db.session.commit()
        flash(f'User {user.username} deleted successfully!', 'success')
    except Exception as e:
        db.session.rollback()
        logger.error(f"User deletion error: {e}")
        flash('An error occurred while deleting the user.', 'danger')
    
    return redirect(url_for('auth.admin_panel'))

# Content and comments pages
@auth_bp.route('/content')
@login_required
def content():
    return render_template('content.html', title='Content Management')

@auth_bp.route('/comments')
@login_required
@role_required('admin', 'moderator')
def comments():
    return render_template('comments.html', title='Comment Moderation')

# JWT token refresh endpoint
@auth_bp.route('/refresh', methods=['POST'])
@jwt_required(refresh=True)
def refresh():
    current_user_id = get_jwt_identity()
    user = User.query.get(current_user_id)
    
    if not user:
        return jsonify({"msg": "User not found"}), 404
    
    access_token = create_access_token(identity=current_user_id, additional_claims={"role": user.role})
    return jsonify(access_token=access_token)
