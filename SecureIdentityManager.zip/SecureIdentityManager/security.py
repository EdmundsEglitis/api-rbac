import re
import logging
from functools import wraps
from flask import jsonify, current_app, request
from flask_jwt_extended import verify_jwt_in_request, get_jwt

logger = logging.getLogger(__name__)

def verify_password_strength(password):
    """
    Verify password meets security requirements:
    - At least 8 characters long
    - Contains at least one uppercase letter
    - Contains at least one lowercase letter
    - Contains at least one number
    """
    if len(password) < 8:
        return False
    
    if not re.search(r'[A-Z]', password):
        return False
        
    if not re.search(r'[a-z]', password):
        return False
        
    if not re.search(r'\d', password):
        return False
    
    return True

def role_required(*roles):
    """
    Decorator for checking if the current user has one of the required roles.
    Can be used with multiple roles: @role_required('admin', 'editor')
    """
    def wrapper(fn):
        @wraps(fn)
        def decorator(*args, **kwargs):
            verify_jwt_in_request()
            claims = get_jwt()
            user_role = claims.get('role', '')
            
            if user_role not in roles:
                logger.warning(f"Unauthorized access attempt: User with role '{user_role}' tried to access endpoint requiring one of roles: {roles}")
                return jsonify({"msg": "Access denied: insufficient privileges"}), 403
            
            return fn(*args, **kwargs)
        return decorator
    return wrapper

def log_access_attempt(user_id, endpoint, success):
    """Log access attempts for auditing"""
    status = "successful" if success else "failed"
    ip = request.remote_addr
    logger.info(f"Access attempt: User ID {user_id}, Endpoint {endpoint}, IP {ip}, Status {status}")

def check_jwt_revoked():
    """
    Helper function to check if a JWT token has been revoked.
    Used in app.py with @jwt.token_in_blocklist_loader
    """
    from models import TokenBlocklist, db
    jti = get_jwt()["jti"]
    token = db.session.query(TokenBlocklist.id).filter_by(jti=jti).scalar()
    return token is not None
